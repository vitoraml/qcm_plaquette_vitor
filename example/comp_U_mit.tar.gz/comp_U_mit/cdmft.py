import numpy as np
import pandas as pd
import os
import pyqcm
from model import model
from pyqcm.cdmft import CDMFT
from scipy.optimize import brentq

pyqcm.set_global_parameter('max_iter_lanczos', 4000)
pyqcm.set_global_parameter('Ground_state_method','P')
pyqcm.set_global_parameter('periodization','M')

var=[]
for j in range(1,2):
    for i in range(1,9):
        var.append('eb{:d}_{:d}'.format(i,j))
        var.append('tb{:d}_{:d}'.format(i,j))

u_list=[8,8]

parf = 'cdmft_u' + str(round(u_list[0],4)) + '.tsv'
bp = pd.read_csv(parf, sep='\t')

eb = bp.filter(like='eb').iloc[:, 0:16]
tb = bp.filter(like='tb').iloc[:, 0:16]

eb = eb[eb.columns[::2]]
tb = tb[tb.columns[::2]]

params = pd.concat([eb,tb],axis = 1)
names = np.array(params.columns, dtype=object)
values = np.array(params)[-1]
st = names[0] + ' = ' + str(values[0])+'\n'
index=0
for n in names[1:]:
    index += 1
    st += n + ' = ' + str(values[index])+'\n'
varia_values = st

band_params = """
U = 8
t = 1.0
t1 = 0.196205135
t2 = 0.192278342
mu = 3.8
"""

model.set_target_sectors('R0:N8:S0/R0:N10:S0/R0:N12:S0')
model.set_parameters(band_params + varia_values)

N_mats=100
b=50
wn=[]
for n in range(0,N_mats):           # Generate the matsubara frequencies iwn
    wn.append((2*n+1)*np.pi/b)

model.set_parameter('U',u_list[1])

#CDMFT(model, varia=var, accur=1*1e-6, accur_bath=1*1e-10, convergence='self-energy',  depth=2, accur_dist=1e-10, maxiter = 137000, alpha=0.0, max_value=100000, beta=50, wc=2, initial_step=0.01, grid_type='ifreq')

I = pyqcm.model_instance(model)
I.Green_function_solve()
I.averages(pr=True)
#I.plot_DoS(w=4, eta=0.1, sum=False, progress=True, colors=None, file='dos_u' + str(round(u_list[1],4)) + '.pdf')
#I.mdc(nk=200, eta=0.1, orb=None, spin_down=False, quadrant=False, opt='GF', k_perp=0, freq=0.0, max=None, plane='xy', size=1.0, band_basis=False, sym=None, file='mdc_u' + str(round(u_list[1],4)) + '.pdf')

#os.system('mv cdmft.tsv cdmft_u' + str(round(u_list[1],4)) + '.tsv')
#os.system('mv dos.tsv dos_u' + str(round(u_list[1],4)) + '.tsv')

# DOS

#w=np.arange(-10,10,0.05)

#f=open(r'dos_smear_u' + str(round(u_list[1],4)) + '.tsv','w')

#for n in range(len(w)):
#    A = I.dos(w[n]+0.05*min(5,1+w[n]**2)*1j)
#    f.write(str(round(w[n],4))+'        '+str(A[0])+'\n')
#f.close()

# Bands

#w=np.arange(-10,10,0.05)
#
#nk = 201
#
#kx = ky = np.linspace(0,0.5,nk)
#
#f=open(r'g_u' + str(round(u_list[1],4)) + '.tsv','w')
#
#for n in range(0,len(w)):
#    for i in range(0,len(kx)):
#        for j in range(0,len(ky)):
#            G = I.periodized_Green_function(w[n]+0.05*min(5,1+w[n]**2)*1j, np.array([kx[i],ky[j],0.0]))
#            f1.write(str(round(w[n],4))+'        '+str(round(kx[i],6))+'        '+str(round(ky[j],6))+'        '+str(float(np.real(G)))+'        '+str(float(np.imag(G)))+'\n')
#
#f.close()
#

w=np.arange(-2,2,0.01)

nk = 201

kx = ky = np.linspace(0,0.5,nk)

f=open(r'e_u' + str(round(u_list[1],4)) + '.tsv','w')

for n in range(0,len(w)):
    for i in range(0,len(kx)):
        for j in range(0,len(ky)):
            E = I.self_energy(w[n]+0.05*min(5,1+w[n]**2)*1j, np.array([kx[i],ky[j],0.0]))
            f.write(str(round(w[n],4))+'        '+str(round(kx[i],6))+'        '+str(round(ky[j],6))+'        '+str(float(np.real(E)))+'        '+str(float(np.imag(E)))+'\n')
f.close()

# Sigma cluster

#e11=open(r'e11_u' + str(round(u_list[1],4)) + '.tsv','w')
#e12y=open(r'e12y_u' + str(round(u_list[1],4)) + '.tsv','w')
#e12x=open(r'e12x_u' + str(round(u_list[1],4)) + '.tsv','w')
#e13=open(r'e13_u' + str(round(u_list[1],4)) + '.tsv','w')
#
#for n in range(0,len(w)):
#    Ew = I.cluster_self_energy(w[n]+0.05*min(5,1+w[n]**2)*1j, clus=0)
#    E00 = Ew[0,0]
#    E10 = Ew[0,1]
#    E01 = Ew[0,2]
#    E11 = Ew[0,3]
#    e11.write(str(w[n])+'        '+str(np.real(np.array([E00]))[0])+'        '+str(np.imag(np.array([E00]))[0])+'\n')
#    e12y.write(str(w[n])+'        '+str(np.real(np.array([E01]))[0])+'        '+str(np.imag(np.array([E01]))[0])+'\n')
#    e12x.write(str(w[n])+'        '+str(np.real(np.array([E10]))[0])+'        '+str(np.imag(np.array([E10]))[0])+'\n')
#    e13.write(str(w[n])+'        '+str(np.real(np.array([E11]))[0])+'        '+str(np.imag(np.array([E11]))[0])+'\n')
#
#e11.close()
#e12y.close()
#e12x.close()
#e13.close()
#
#print('\n\n'+r'Plotting cluster G and $\Sigma$ in matsubara frequencies' +'\n\n')
#
#f11=open(r'g11_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#f12y=open(r'g12y_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#f12x=open(r'g12x_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#f13=open(r'g13_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#e11=open(r'e11_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#e12y=open(r'e12y_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#e12x=open(r'e12x_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#e13=open(r'e13_mats_d' + str(round(d_list[1],4)) + '.tsv','w')
#
#for n in range(0,len(wn)):
#    Gw = I.cluster_Green_function(wn[n]*1j, clus=0)
#    G00 = Gw[0,0]
#    G10 = Gw[0,1]
#    G01 = Gw[0,2]
#    G11 = Gw[0,3]
#    f11.write(str(wn[n])+'        '+str(np.real(np.array([G00]))[0])+'        '+str(np.imag(np.array([G00]))[0])+'\n')
#    f12y.write(str(wn[n])+'        '+str(np.real(np.array([G01]))[0])+'        '+str(np.imag(np.array([G01]))[0])+'\n')
#    f12x.write(str(wn[n])+'        '+str(np.real(np.array([G10]))[0])+'        '+str(np.imag(np.array([G10]))[0])+'\n')
#    f13.write(str(wn[n])+'        '+str(np.real(np.array([G11]))[0])+'        '+str(np.imag(np.array([G11]))[0])+'\n')
#    Ew = I.cluster_self_energy(wn[n]*1j, clus=0)
#    E00 = Ew[0,0]
#    E10 = Ew[0,1]
#    E01 = Ew[0,2]
#    E11 = Ew[0,3]
#    e11.write(str(wn[n])+'        '+str(np.real(np.array([E00]))[0])+'        '+str(np.imag(np.array([E00]))[0])+'\n')
#    e12y.write(str(wn[n])+'        '+str(np.real(np.array([E01]))[0])+'        '+str(np.imag(np.array([E01]))[0])+'\n')
#    e12x.write(str(wn[n])+'        '+str(np.real(np.array([E10]))[0])+'        '+str(np.imag(np.array([E10]))[0])+'\n')
#    e13.write(str(wn[n])+'        '+str(np.real(np.array([E11]))[0])+'        '+str(np.imag(np.array([E11]))[0])+'\n')
#
#f11.close()
#f12x.close()
#f13.close()
#e11.close()
#e12y.close()
#e12x.close()
#e13.close()

#print('\n\n'+r'Plotting MDC' +'\n\n')

#w=np.arange(-0.3,0.3,0.01)

#nk = 101

#kx = ky = np.linspace(-0.5,0.5,nk)

#w_qpi = np.arange(-2,0.01,0.1)

#print(w_qpi)

#kx_red = ky_red = np.linspace(0.0,0.5,nk)

#nk_mdc = 801

#kx_mdc = ky_mdc = np.linspace(0.0,0.5,nk_mdc)

# Real w (mdc)
#
#f1=open(r'mdc_d' + str(round(d_list[1],4)) + '_spec.tsv','w')
#f2=open(r'mdc_d' + str(round(d_list[1],4)) + '_sigma.tsv','w')
#
#for i in range(0,len(kx)):
#    for j in range(0,len(ky)):
#        G_per = I.periodized_Green_function(0.05*1j, np.array([kx[i],ky[j],0.0]))
#        E_per = I.self_energy(0.05*1j, np.array([kx[i],ky[j],0.0]))
#        f1.write(str(round(kx[i],6))+'        '+str(round(ky[j],6))+'        '+str(float(np.real(G_per)))+'        '+str(float(np.imag(G_per)))+'\n')
#        f2.write(str(round(kx[i],6))+'        '+str(round(ky[j],6))+'        '+str(float(np.real(E_per)))+'        '+str(float(np.imag(E_per)))+'\n')
#
#f1.close()
#f2.close()
#
# Some w mdc

#for n in range(0,len(w_qpi)):
#    f1=open(r'mdcw'+str(n)+'_d' + str(round(d_list[1],4)) + '_spec.tsv','w')
#    for i in range(0,len(kx)):
#        for j in range(0,len(ky)):
#            G_per = I.periodized_Green_function(w_qpi[n]+0.05*min(5,1+w_qpi[n]**2)*1j, np.array([kx[i],ky[j],0.0]))
#            f1.write(str(round(kx[i],6))+'        '+str(round(ky[j],6))+'        '+str(float(np.real(G_per)))+'        '+str(float(np.imag(G_per)))+'\n')
#    f1.close()

#f1=open(r'xy_' + str(round(d_list[1],4)) + '_spec.tsv','w')

#for n in range(0,len(w_qpi)):
#    G = I.cluster_Green_function(w_qpi[n]+0.05*min(5,1+w_qpi[n]**2)*1j, clus=0)
#    G_per_x = G[0,0]-G[0,1]+G[0,2]-G[0,3]
#    G_per_y = G[0,0]+G[0,1]-G[0,2]-G[0,3]
#    f1.write(str(w_qpi[n])+'        '+str(float(np.imag(G_per_x)))+'        '+str(float(np.imag(G_per_y)))+'\n')

#f1.close()

# Dense real w (mdc)

#f1=open(r'mdc_d' + str(round(d_list[1],4)) + '_spec_red.tsv','w')
#f2=open(r'mdc_d' + str(round(d_list[1],4)) + '_sigma_red.tsv','w')

#for i in range(0,len(kx_mdc)):
#    for j in range(0,len(ky_mdc)):
#        G_per = I.periodized_Green_function(0.1*1j, np.array([kx_mdc[i],ky_mdc[j],0.0]))
#        E_per = I.self_energy(0.1*1j, np.array([kx_mdc[i],ky_mdc[j],0.0]))
#        f1.write(str(round(kx_mdc[i],6))+'        '+str(round(ky_mdc[j],6))+'        '+str(float(np.real(G_per)))+'        '+str(float(np.imag(G_per)))+'\n')
#        f2.write(str(round(kx_mdc[i],6))+'        '+str(round(ky_mdc[j],6))+'        '+str(float(np.real(E_per)))+'        '+str(float(np.imag(E_per)))+'\n')

#f1.close()
#f2.close()

#f1=open(r'fs_d' + str(round(d_list[1],4)) + '_spec.tsv','w')
#
#for i in range(0,len(kx_red)):
#    for j in range(0,len(ky_red)):
#        G_per = I.periodized_Green_function(1e-4*1j, np.array([kx_red[i],ky_red[j],0.0]))
#        f1.write(str(round(kx_red[i],6))+'        '+str(round(ky_red[j],6))+'        '+str(float(np.real(G_per)))+'        '+str(float(np.imag(G_per)))+'\n')
#
#f1.close()
#
## Real w (disp)
#
#print('\n\n'+r'Plotting preiodized A and G from -4 to 4' +'\n\n')
#
#f1=open(r'g_d' + str(round(d_list[1],4)) + '.tsv','w')
#f2=open(r'e_d' + str(round(d_list[1],4)) + '.tsv','w')
#
#for n in range(0,len(w)):
#    for i in range(0,len(kx_red)):
#        for j in range(0,len(ky_red)):
#            G = I.periodized_Green_function(w[n]+0.05+0.05*min(5,1+w[n]**2)*1j, np.array([kx_red[i],ky_red[j],0.0]))
#            E = I.self_energy(w[n]+0.05+0.05*min(5,1+w[n]**2)*1j, np.array([kx_red[i],ky_red[j],0.0]))
#            f1.write(str(round(w[n],4))+'        '+str(round(kx_red[i],6))+'        '+str(round(ky_red[j],6))+'        '+str(float(np.real(G)))+'        '+str(float(np.imag(G)))+'\n')
#            f2.write(str(round(w[n],4))+'        '+str(round(kx_red[i],6))+'        '+str(round(ky_red[j],6))+'        '+str(float(np.real(E)))+'        '+str(float(np.imag(E)))+'\n')
#
#f1.close()
#f2.close()
#
#print('\n\n'+r'Calculating the potential energy' +'\n\n')
#
#Pott=I.Potthoff_functional(file='free_ene_M'+str(round(M_list[1],3))+'.tsv')
#print('Potthoff='+' '+str(Pott))
