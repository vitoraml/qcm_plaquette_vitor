import numpy as np
import pandas as pd
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

############ Function defining the size of the labels ###############
def set_size(w,h, ax=None):
    """ w, h: width, height in inches """
    if not ax: ax=plt.gca()
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w)/(r-l)
    figh = float(h)/(t-b)
    ax.figure.set_size_inches(figw, figh)

u=8

f=open(r'g_u'+str(u)+'.tsv','r')

spec = [[],[],[],[]]

nk = 201

w=np.arange(-10,10,0.05)

k1 = np.linspace(0,0.5,nk)
k2 = np.linspace(0.5,1,nk)
k3 = np.linspace(1,1.5,nk)
k4 = np.linspace(1.5,2,nk)
k5 = np.linspace(2,2.5,nk)

# Data analysis

# Spec

for line in f:
    v=[float(n) for n in line.split()]
    spec[0].append(v[0])
    spec[1].append(v[1])
    spec[2].append(v[2])
    spec[3].append(-v[4]/np.pi)
f.close()

# G-X

gx = []

for i in range(0,len(w)*nk*nk):
    if spec[1][i] == 0.0:
        gx.append(spec[3][i])

gx = np.reshape(gx,(len(w),nk))

# X-M

xm = []

for i in range(0,len(w)*nk*nk):
    if spec[2][i] == 0.5:
        xm.append(spec[3][i])

xm = np.reshape(xm,(len(w),nk))

# M-Y

my = []

for i in range(0,len(w)*nk*nk):
    if spec[1][i] == 0.5:
        my.append(spec[3][i])

my = np.reshape(my,(len(w),nk))
my = my[:,::-1]

# Y-G

yg = []

for i in range(0,len(w)*nk*nk):
    if spec[2][i] == 0.0:
        yg.append(spec[3][i])

yg = np.reshape(yg,(len(w),nk))
yg = yg[:,::-1]

# G-M

gm = []

for i in range(0,len(w)*nk*nk):
    if spec[1][i] == spec[2][i]:
        gm.append(spec[3][i])

gm = np.reshape(gm,(len(w),nk))
#gm = gm[:,::-1]

# Plot

z_min = gx.min()
z_max = my.max()
z_max2 = gm.max()

plt.figure()
ax = plt.gca()
#ax.set_aspect(1)

#cs1 = ax.contourf(k1,w,gx,np.linspace(z_min, z_max, 40), cmap='jet')
#ax.contourf(k2,w,xm,np.linspace(z_min, z_max, 40), cmap='jet')
#ax.contourf(k3,w,my,np.linspace(z_min, z_max, 40), cmap='jet')
#ax.contourf(k4,w,yg,np.linspace(z_min, z_max, 40), cmap='jet')
#ax.contourf(k5,w,gm,np.linspace(z_min, z_max, 40), cmap='jet')

cs1 = ax.contourf(k1,w,gx,np.linspace(0, z_max, 40), cmap='hot')
ax.contourf(k2,w,xm,np.linspace(0, z_max, 40), cmap='hot')
ax.contourf(k3,w,my,np.linspace(0, z_max, 40), cmap='hot')
ax.contourf(k4,w,yg,np.linspace(0, z_max, 40), cmap='hot')
ax.contourf(k5,w,gm,np.linspace(0, z_max, 40), cmap='hot')

#ax.set_xlabel('$k$',fontsize=16)
ax.set_ylabel('$\omega$',fontsize=16)
ax.tick_params(axis='x',labelsize=14)
ax.tick_params(axis='y',labelsize=14)

plt.axvline(0.5,c='gray',ls='dashed',lw=1)
plt.axvline(1,c='gray',ls='dashed',lw=1)
plt.axvline(1.5,c='gray',ls='dashed',lw=1)
plt.axvline(2,c='gray',ls='dashed',lw=1)
plt.xticks([0,0.5,1,1.5,2,2.5],[r'$\Gamma$','X','M','Y',r'$\Gamma$','M'])
plt.xlim([0,2.5])
plt.ylim([-10,10])

set_size(5,4)
plt.colorbar(cs1,shrink=1.0)
plt.tight_layout()
plt.savefig('spec_bands_u'+str(u)+'.png')
plt.show()
