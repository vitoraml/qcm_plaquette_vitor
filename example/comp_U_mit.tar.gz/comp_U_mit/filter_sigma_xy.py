import numpy as np

# Files and definitions

u=8

f=open(r'e_u'+str(u)+'.tsv','r')

spec_re = [[],[],[],[]]
spec_im = [[],[],[],[]]

w=np.arange(-2,2,0.01)

nk = 201

k = np.linspace(0,0.5,nk)

# Data analysis

# Read spec

for line in f:
    v=[float(n) for n in line.split()]
    spec_re[0].append(v[0])     # w
    spec_im[0].append(v[0])
    spec_re[1].append(v[1])     # kx
    spec_im[1].append(v[1])
    spec_re[2].append(v[2])     # ky
    spec_im[2].append(v[2])
    spec_re[3].append(v[3])     # spec
    spec_im[3].append(v[4])     
f.close()

# X-Y

xy_re = []
xy_im = []

for i in range(0,len(w)*nk*nk):
    if (spec_re[1][i]+spec_re[2][i]) == 0.5:
        xy_re.append(spec_re[3][i])

xy_re = np.reshape(xy_re,(len(w),nk))

for i in range(0,len(w)*nk*nk):
    if (spec_im[1][i]+spec_im[2][i]) == 0.5:
        xy_im.append(spec_im[3][i])

xy_im = np.reshape(xy_im,(len(w),nk))

# Write

f=open(r'sigma_xy_u'+str(u)+'.tsv','w')

for i in range(nk):
    for j in range(len(w)):
        f.write(str(w[j])+'    '+str(k[i])+'    '+str(xy_re[j][i])+'    '+str(xy_im[j][i])+'\n')

f.close()
