import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np

############ Function defining the size of the labels ###############
def set_size(w,h, ax=None):
    """ w, h: width, height in inches """
    if not ax: ax=plt.gca()
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w)/(r-l)
    figh = float(h)/(t-b)
    ax.figure.set_size_inches(figw, figh)

u=8

w=np.arange(-10,10,0.05)

f1=open(r'e11_u'+str(u)+'.tsv','r')
f2=open(r'e12x_u'+str(u)+'.tsv','r')
f3=open(r'e13_u'+str(u)+'.tsv','r')

y1, y2, y3, y4 = [], [], [], []
g00, gp0, gpp = [], [], []

for line in f1:
    v=[float(n) for n in line.split()]
    y1.append(v[2])
f1.close()

for line in f2:
    v=[float(n) for n in line.split()]
    y2.append(v[2])
f2.close()

for line in f3:
    v=[float(n) for n in line.split()]
    y3.append(v[2])
f3.close()

for j in range(0,len(y1)):
    g00.append(y1[j]+2*y2[j]+y3[j])
    gp0.append(y1[j]-y3[j])
    gpp.append(y1[j]-2*y2[j]+y3[j])

# Plot

fig, ax=plt.subplots()

plt.xlim([-10,10])
plt.ylim([-50.0,0])
plt.xlabel('$\omega$', fontsize=16)
plt.ylabel('Im[$\Sigma[0,0]$]', fontsize=16)
plt.axvline(0,c='k',ls='dotted')

ax.plot(w,g00,c='k',ls='-', lw=2, label='')

set_size(5,4)
plt.tight_layout()
#plt.legend(loc='lower left',fontsize=14)
plt.savefig('e00.png', dpi=300)
plt.show()

fig, ax=plt.subplots()

plt.xlim([-10,10])
plt.ylim([-110.0,0])
plt.xlabel('$\omega$', fontsize=16)
plt.ylabel('Im[$\Sigma[\pi,0]]$', fontsize=16)
plt.axvline(0,c='k',ls='dotted')

ax.plot(w,gp0,c='k',ls='-', lw=2, label='')

set_size(5,4)
plt.tight_layout()
#plt.legend(loc='lower left',fontsize=14)
plt.savefig('ep0.png', dpi=300)
plt.show()

fig, ax=plt.subplots()

plt.xlim([-10,10])
plt.ylim([-50.0,0])
plt.xlabel('$\omega$', fontsize=16)
plt.ylabel('Im[$\Sigma[\pi,\pi]]$', fontsize=16)
plt.axvline(0,c='k',ls='dotted')

ax.plot(w,gpp,c='k',ls='-', lw=2, label='')

set_size(5,4)
plt.tight_layout()
#plt.legend(loc='lower left',fontsize=14)
plt.savefig('epp.png', dpi=300)
plt.show()
