import numpy as np

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.patches as patches
from matplotlib.colors import hsv_to_rgb

############ Function defining the size of the labels ###############
def set_size(w,h, ax=None):
    """ w, h: width, height in inches """
    if not ax: ax=plt.gca()
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w)/(r-l)
    figh = float(h)/(t-b)
    ax.figure.set_size_inches(figw, figh)

# Files and definitions

u=8

f=open(r'sigma_xy_u'+str(u)+'.tsv','r')

spec = []

w=np.arange(-2.04,1.96,0.01)

nk = 201

# Data analysis

# Read spec

for line in f:
    v=[float(n) for n in line.split()]
    spec.append(-v[3])     # spec
f.close()

offset=3.5

#print(xy)
#print(len(xy))

xy = np.reshape(spec,(nk,len(w)))
#print(gm)

# Plot

fig, ax=plt.subplots()
plt.xlim([-0.2,0.2])
#plt.ylim([0,16])
plt.xlabel('$\omega$',fontsize=16)
plt.ylabel('-Im[$\Sigma(k,\omega$)]',fontsize=16)
plt.axvline(0,c='k',ls='dotted')

n=0

for i in range(nk):
    if i%2 == 0:
        xy_p=[]
        for j in range(len(w)):
            xy_p.append(xy[i][j]+offset*n)
        ax.plot(w,xy_p,c='k',ls='-', lw=1.5)
        n = n + 1

#ax.plot(w,xy[:,0],c='k',ls='-', lw=1.5)

set_size(5,4)
plt.tight_layout()
#plt.legend(loc='upper right',fontsize=7)
plt.savefig('sigma_cdmft_xy_u'+str(u)+'.png', dpi=300)
plt.show()
