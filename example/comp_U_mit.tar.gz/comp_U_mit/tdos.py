import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import matplotlib.gridspec as gridspec
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

############ Function defining the size of the labels ###############
def set_size(w,h, ax=None):
    """ w, h: width, height in inches """
    if not ax: ax=plt.gca()
    l = ax.figure.subplotpars.left
    r = ax.figure.subplotpars.right
    t = ax.figure.subplotpars.top
    b = ax.figure.subplotpars.bottom
    figw = float(w)/(r-l)
    figh = float(h)/(t-b)
    ax.figure.set_size_inches(figw, figh)

u_list=[1,8]

fig, ax=plt.subplots()
plt.xlim([-10,10])
#plt.ylim([0.0,0.6])
plt.xlabel('$\omega$',fontsize=16)
plt.ylabel('A($\omega$)',fontsize=16)
plt.axvline(0,c='k',ls='dotted')
plt.axhline(0,c='k',ls='-', lw=1)
cmap = mpl.colormaps['inferno']
color = cmap(np.linspace(0,0.8,len(u_list)))

for i in range(0,len(u_list)):
    f = open(r'dos_smear_u'+str(round(u_list[i],3))+'.tsv','r')
    x1, x2, y1, y2 = [], [], [], []

    next(f)
    for line in f:
        v=[float(n) for n in line.split()]
        x1.append(v[0])
        y1.append(v[1])
    ax.plot(x1,y1,c=color[i],ls='-', lw=2, label='U='+str(round(u_list[i],3)))
    f.close()

ax.tick_params(axis='x',labelsize=14)
ax.tick_params(axis='y',labelsize=14)

#legend = ax.legend()

set_size(8,4)
plt.tight_layout()
plt.legend(loc='upper right',fontsize=12)
plt.savefig('dos_comp_mit.png', dpi=300)
plt.show()

