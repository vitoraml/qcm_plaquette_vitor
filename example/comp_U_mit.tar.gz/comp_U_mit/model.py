import pyqcm
from cluster_c2v import cm
# Defining the lattice model

pos_cu = [[0,0,0], [1,0,0], [0,1,0], [1,1,0]]
clus_cu = pyqcm.cluster(cm, pos_cu)
model = pyqcm.lattice_model('model', clus_cu, [[2,0,0],[0,2,0]],[[1,0,0],[0,1,0]])
#================================================================================
# lattice operators

# U
model.interaction_operator('U')

# t
model.hopping_operator('t', [1, 0, 0],-1)
model.hopping_operator('t', [0, 1, 0],-1)

# t'
model.hopping_operator('t1', [1, 1, 0], 1)
model.hopping_operator('t1', [1,-1, 0], 1)

# t''
model.hopping_operator('t2', [2, 0, 0],-1)
model.hopping_operator('t2', [0, 2, 0],-1)
